﻿namespace Quantum_QFOR
{
    internal class clsUtil_ExportTransaction_AP
    {
    }
}