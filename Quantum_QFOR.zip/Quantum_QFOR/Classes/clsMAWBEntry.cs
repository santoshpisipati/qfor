﻿namespace Quantum_QFOR
{
    internal class clsMAWBEntry
    {
    }
}