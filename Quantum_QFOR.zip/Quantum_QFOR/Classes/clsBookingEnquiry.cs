﻿namespace Quantum_QFOR
{
    internal class clsBookingEnquiry
    {
    }
}