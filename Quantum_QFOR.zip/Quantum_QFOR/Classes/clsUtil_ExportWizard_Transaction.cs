﻿namespace Quantum_QFOR
{
    internal class clsUtil_ExportWizard_Transaction
    {
    }
}