﻿namespace Quantum_QFOR
{
    internal class clsCollectionlist
    {
    }
}