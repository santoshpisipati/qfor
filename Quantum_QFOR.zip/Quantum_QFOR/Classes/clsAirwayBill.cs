﻿namespace Quantum_QFOR
{
    internal class clsAirwayBill
    {
    }
}