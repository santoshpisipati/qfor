﻿namespace Quantum_QFOR.Models
{
    public class EmployeeModel
    {
        // sample comment for check in
    }
}