﻿namespace Quantum_QFOR.Models
{
    public class CustomerProfileModel
    {
        public string CorporateId { get; set; }
        public string CorporateName { get; set; }
        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public string Address3 { get; set; }
        public string City { get; set; }
    }
}